package com.example.demo.exception;

public class LandVerificationException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public LandVerificationException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public LandVerificationException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}
	
	

}
