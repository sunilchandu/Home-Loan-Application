package com.example.demo.exception;

public class AdminApprovalException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AdminApprovalException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AdminApprovalException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
