package com.example.demo.exception;

public class FinanceVerificationException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;



	public FinanceVerificationException() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public FinanceVerificationException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}


	
}
