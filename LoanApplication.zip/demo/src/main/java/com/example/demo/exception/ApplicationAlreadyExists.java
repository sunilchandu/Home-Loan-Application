package com.example.demo.exception;

public class ApplicationAlreadyExists extends Exception{
	
	public ApplicationAlreadyExists(String msg)
	{
	super(msg);
	}

}
