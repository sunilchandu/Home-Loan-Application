package com.example.demo.exception;

public class ApplicationIdNotFound extends Exception {
	public ApplicationIdNotFound(String msg) {
		super(msg);
	}

}
